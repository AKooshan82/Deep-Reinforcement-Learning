# Latex styles I use for uni

this is just a simple set of latex styles i use regularly for my uni related documents.
`main.tex` shows a sample of how i use it.

> this repo will be updated as I add more and more styles.
